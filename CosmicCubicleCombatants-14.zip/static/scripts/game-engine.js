document.addEventListener("DOMContentLoaded", () => {
    const canvas = document.getElementById("gameCanvas");
    const ctx = canvas.getContext("2d");
    canvas.width = canvas.clientWidth;
    canvas.height = canvas.clientHeight;

    let encounters = null;
    fetch("/static/data/encounters.json")
        .then(res => res.json())
        .then(data => {
            encounters = data;
            setupAndRun();
        });

    function setupAndRun() {
        const config = {
            map: {
                width: 10,
                height: 10,
                grid: [
                    1,1,1,1,1,1,1,1,1,1,
                    1,0,0,0,0,0,0,0,0,1,
                    1,0,1,0,1,0,1,0,0,1,
                    1,0,1,0,1,0,1,0,0,1,
                    1,0,0,0,0,0,0,0,0,1,
                    1,0,1,1,1,1,1,1,0,1,
                    1,0,0,0,0,0,0,1,0,1,
                    1,1,1,1,0,1,0,1,0,1,
                    1,0,0,0,0,1,0,0,0,1,
                    1,1,1,1,1,1,1,1,1,1
                ]
            },
            player: {
                x: 5,
                y: 6.5,
                dir: -Math.PI / 2,
                fov: Math.PI / 4
            }
        };

        let currentMessage = "";
        let messageTimer = 0;

        const keys = {};
        document.addEventListener("keydown", e => keys[e.key] = true);
        document.addEventListener("keyup", e => keys[e.key] = false);

        function movePlayer() {
            const speed = 0.1;
            const rotSpeed = 0.05;

            if (keys["ArrowLeft"] || keys["a"]) config.player.dir -= rotSpeed;
            if (keys["ArrowRight"] || keys["d"]) config.player.dir += rotSpeed;

            let moveX = 0, moveY = 0;
            if (keys["ArrowUp"] || keys["w"]) {
                moveX = Math.cos(config.player.dir) * speed;
                moveY = Math.sin(config.player.dir) * speed;
            }
            if (keys["ArrowDown"] || keys["s"]) {
                moveX = -Math.cos(config.player.dir) * speed;
                moveY = -Math.sin(config.player.dir) * speed;
            }

            let newX = config.player.x + moveX;
            let newY = config.player.y + moveY;
            const indexX = Math.floor(config.player.y) * config.map.width + Math.floor(newX);
            const indexY = Math.floor(newY) * config.map.width + Math.floor(config.player.x);

            if (config.map.grid[indexX] === 0) config.player.x = newX;
            if (config.map.grid[indexY] === 0) config.player.y = newY;

            checkEncounters();
        }

        function checkEncounters() {
            const px = Math.floor(config.player.x);
            const py = Math.floor(config.player.y);
            currentMessage = "";

            if (Math.random() < 0.5 && encounters && encounters.puns.length > 0) {
                currentMessage = encounters.puns[Math.floor(Math.random() * encounters.puns.length)];
                messageTimer = 100;
                return;
            }

            for (const npc of encounters.npc_encounters) {
                if (npc.location[0] === px && npc.location[1] === py) {
                    currentMessage = npc.lines[Math.floor(Math.random() * npc.lines.length)];
                    messageTimer = 100;
                    return;
                }
            }
        }

        function castRay(angle) {
            const { x, y } = config.player;
            let sin = Math.sin(angle);
            let cos = Math.cos(angle);

            for (let t = 0; t < 20; t += 0.05) {
                let dx = x + cos * t;
                let dy = y + sin * t;
                let mx = Math.floor(dx);
                let my = Math.floor(dy);
                let index = my * config.map.width + mx;
                if (index < 0 || index >= config.map.grid.length) break;
                if (config.map.grid[index] === 1) return t;
            }
            return 20;
        }

        function drawScene() {
            const { x, y, dir, fov } = config.player;
            const screenWidth = canvas.width;
            const screenHeight = canvas.height;
            const numRays = screenWidth;

            ctx.fillStyle = "#222";
            ctx.fillRect(0, 0, screenWidth, screenHeight / 2);
            ctx.fillStyle = "#444";
            ctx.fillRect(0, screenHeight / 2, screenWidth, screenHeight / 2);

            for (let i = 0; i < numRays; i++) {
                let rayAngle = dir - fov / 2 + fov * (i / numRays);
                let distance = castRay(rayAngle);
                let height = screenHeight / (distance + 0.001);
                let shade = 255 - Math.min(255, distance * 30);
                ctx.fillStyle = `rgb(${shade}, ${shade * 0.9}, ${shade * 0.7})`;
                ctx.fillRect(i, (screenHeight - height) / 2, 1, height);
            }

            if (messageTimer > 0) {
                ctx.fillStyle = "#fff";
                ctx.font = "16px sans-serif";
                ctx.fillText(currentMessage, screenWidth / 2 - ctx.measureText(currentMessage).width / 2, 30);
                messageTimer--;
            }

            ctx.strokeStyle = "#fff";
            ctx.beginPath();
            ctx.moveTo(screenWidth / 2 - 5, screenHeight / 2);
            ctx.lineTo(screenWidth / 2 + 5, screenHeight / 2);
            ctx.moveTo(screenWidth / 2, screenHeight / 2 - 5);
            ctx.lineTo(screenWidth / 2, screenHeight / 2 + 5);
            ctx.stroke();
        }

        function loop() {
            movePlayer();
            drawScene();
            requestAnimationFrame(loop);
        }

        loop();
    }
});
